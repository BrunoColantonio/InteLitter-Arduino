package com.example.shake;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends Activity implements SensorEventListener, CompoundButton.OnCheckedChangeListener
{

    private final static float ACC = 10;
    private MediaPlayer mediaPlayer;
    int last = 0;

    private Switch checkBox;
    private SensorManager sensorManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        checkBox = findViewById(R.id.checkbox);
        checkBox.setOnCheckedChangeListener(this);

//        mediaPlayer = new MediaPlayer();
        mediaPlayer = MediaPlayer.create(this, R.raw.microsoft_windows_xp_shutdown_sound);


        mediaPlayer.setOnPreparedListener(
                new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mp) {
                        Log.e("Ready","Ready!!");
                        mp.setVolume(1.0f,1.0f);
                    }
                }
        );

    }

    private void startPlayer(String file)
    {
        try {
            Uri uri = Uri.parse(file);
            mediaPlayer.reset();
            mediaPlayer.setDataSource(this,uri);
            mediaPlayer.start();
        }catch (IOException exception){
            exception.printStackTrace();
        }

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
    {
        if (isChecked)
        {
            registerSensor();
        }
        else
        {
            unregisterSensor();
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();

        if (checkBox.isChecked())
        {
            registerSensor();
        }

    }

    @Override
    protected void onStop()
    {
        unregisterSensor();
        if (mediaPlayer != null)
        {
            mediaPlayer.release();
        }
        super.onStop();
    }

    @Override
    protected void onPause()
    {
        if (checkBox.isChecked())
        {
            unregisterSensor();
        }
        super.onPause();
    }


    private void registerSensor()
    {
        boolean done = sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);

        if (!done)
        {
            Toast.makeText(this, getResources().getString(R.string.sensor_unsupported), Toast.LENGTH_SHORT).show();
            checkBox.setChecked(false);
        }

        Log.i("sensor", "register");
    }

    private void unregisterSensor()
    {
        sensorManager.unregisterListener(this);
        Log.i("sensor", "unregister");
    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent)
    {
        int sensorType = sensorEvent.sensor.getType();

        float[] values = sensorEvent.values;

        if (sensorType == Sensor.TYPE_ACCELEROMETER)
        {
            if ((Math.abs(values[0]) > ACC || Math.abs(values[1]) > ACC || Math.abs(values[2]) > ACC ))
            {
//                switch (last)
//                {
//                    case 0:
//                        startPlayer("android.resource://com.example.shake/raw/windowsXpStartup");
//                        last = 1;
//                        break;
//                    case 1:
//                        startPlayer("android.resource://com.example.shake/raw/microsoftWindowsXpShutdownSound");
//                        last = 0;
//                        break;
//                }
                mediaPlayer.start();
            }

        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i)
    {

    }
}